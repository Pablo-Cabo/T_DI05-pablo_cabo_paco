package com.example.btninformes;

import javafx.beans.property.*;

public class Artists {
    private final IntegerProperty id = new SimpleIntegerProperty();
    private final StringProperty name = new SimpleStringProperty();

    public Artists() {

    }

    public Artists(int id, String title) {
        this.id.set(id);
        this.name.set(title);
    }

    public int getId() {
        return id.get();
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public String getName() {
        return name.get();
    }

    public StringProperty nameProperty() {
        return name;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    @Override
    public String toString() {
        return "Pelicula{" +
                "id=" + id +
                ", title=" + name +
                '}';
    }
}
