package com.example.btninformes;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.text.Text;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;

import java.io.InputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

public class ArtistsController implements Initializable {

    private final String url ="jdbc:sqlite:db/chinook.db";

    @FXML public Button btnGenerateReport;

    @FXML private TableView<Artists> artistsTable;
    @FXML private TableColumn<Artists, Integer> columnId;
    @FXML private TableColumn<Artists, String> columnName;

    @FXML public Text textName;

    private ObservableList<Artists> listArtists;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        listArtists = DatosArtistas.getInstance().getListaArtistas();

        columnId.setCellValueFactory(data -> data.getValue().idProperty().asObject());
        columnName.setCellValueFactory(data -> data.getValue().nameProperty());

        artistsTable.setItems(listArtists);

        artistsTable.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                textName.setText(newValue.getName());
            } else {
                textName.setText("");
            }
        });

        btnGenerateReport.setDisable(true);
        artistsTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            btnGenerateReport.setDisable(newSelection == null);
        });
    }

    @FXML
    public void generateReport(ActionEvent actionEvent) {
        Artists selectedArtist = artistsTable.getSelectionModel().getSelectedItem();

        if (selectedArtist == null) {
            System.out.println("No se ha seleccionado ningún artista.");
            return;
        }

        try {
            String jasperFilePath = "informes/informeArtista.jrxml";
            InputStream inputStream = MainInforme.class.getResourceAsStream(jasperFilePath);

            JasperReport jasperReport = JasperCompileManager.compileReport(inputStream);

            Connection conn = DriverManager.getConnection(url);

            Map<String, Object> params = new HashMap<>();
            params.put("ArtistaId", selectedArtist.getId());

            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, conn);

            JasperViewer.viewReport(jasperPrint, false);

        } catch (JRException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}