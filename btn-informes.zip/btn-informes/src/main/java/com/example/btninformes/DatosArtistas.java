package com.example.btninformes;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

public class DatosArtistas {

    private static DatosArtistas instancia = null;
    private static ObservableList<Artists> listaArtistas = FXCollections.observableArrayList();
    private final String url = "jdbc:sqlite:db/chinook.db";

    private DatosArtistas() {
        cargarArtistasDesdeBD();
    }

    public static DatosArtistas getInstance() {
        if (instancia == null) {
            instancia = new DatosArtistas();
        }
        return instancia;
    }

    public static ObservableList<Artists> getListaArtistas() {
        return listaArtistas;
    }

    public static void setListaArtistas(ObservableList<Artists> lista) {
        listaArtistas = lista;
    }

    private void cargarArtistasDesdeBD() {
        listaArtistas.clear();

        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT ArtistId, Name FROM artists")) {

            while (rs.next()) {
                listaArtistas.add(new Artists(rs.getInt("ArtistId"), rs.getString("Name")));
            }

            System.out.println("Cargados " + listaArtistas.size() + " artistas desde la BD.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}