package com.example.btninformes;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.stage.Stage;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

public class MainInformeController implements Initializable {

    private final String url ="jdbc:sqlite:db/chinook.db";

    @Override
    public void initialize(URL location, ResourceBundle resources) {}

    @FXML
    public void handlerInformeCliente(ActionEvent actionEvent) {
        try {
            String jasperFilePath = "informes/informeClientes.jrxml";
            InputStream inputStream = MainInforme.class.getResourceAsStream(jasperFilePath);

            JasperReport jasperReport = JasperCompileManager.compileReport(inputStream);

            Connection conn = DriverManager.getConnection(url);

            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, new HashMap<>(), conn);

            JasperViewer.viewReport(jasperPrint, false);

        } catch (JRException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void handlerInformeArtistas(ActionEvent actionEvent) {

        Scene escena = null;
        FXMLLoader fxmlLoader = new FXMLLoader(MainInforme.class.getResource("ArtistsView.fxml"));

        try {
            escena = new Scene(fxmlLoader.load());
        } catch (IOException e) {
            System.out.println("ERROR al cargar la ventana de listar artistas");
            e.printStackTrace();
        }

        ArtistsController controller = fxmlLoader.getController();

        Stage st = new Stage();
        st.setScene(escena);
        st.setTitle("Lista de Artistas");
        st.showAndWait();
    }

    @FXML
    public void handlerCerrar(ActionEvent actionEvent) {
        System.exit(0);
    }
}