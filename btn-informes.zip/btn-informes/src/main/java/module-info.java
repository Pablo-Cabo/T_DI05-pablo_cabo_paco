module com.example.btninformes {
    requires javafx.controls;
    requires javafx.fxml;
    requires jasperreports;
    requires log4j;
    requires org.xerial.sqlitejdbc;
    requires java.sql;


    opens com.example.btninformes;
    exports com.example.btninformes;
}